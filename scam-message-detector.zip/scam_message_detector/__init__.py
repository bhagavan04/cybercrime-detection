from .model import ScamDetector
